package com.nseoffline.preopen.main;

import java.io.IOException;
import java.util.List;
import java.util.Objects;
import java.util.Optional;
import java.util.stream.Collectors;
import java.util.stream.StreamSupport;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.stereotype.Component;

import com.nseindia.redis.connection.ConnectionProp;
import com.nseindia.redis.model.Index;
import com.nseindia.redis.model.PreOpen;
import com.nseindia.redis.model.PreOpenOffline;
import com.nseindia.redis.repo.IndexRepository;
import com.nseindia.redis.repo.PreOpenOfflineRepository;
import com.nseindia.redis.repo.PreOpenRepository;
import com.nseindia.redis.util.KeyMapper;
import com.nseoffline.preopen.dao.PreOpenUpdatesDAO;

import redis.clients.jedis.JedisCluster;

@Component
public class PreOpenUpdates implements CommandLineRunner {

	@Autowired
	PreOpenUpdatesDAO preOpenUpdates;
	
	@Autowired
	IndexRepository indexRepository;
	
	@Autowired
	PreOpenRepository preOpenRepository;
	
	@Autowired
	PreOpenOfflineRepository preOpenOfflineRepository;

	private static final Logger LOGGER=LoggerFactory.getLogger(PreOpenUpdates.class);
	
	@Override
	public void run(String... args) throws Exception {
		getDataFromRDB();
		updateNiftyValue();
		getPreOpenData();
	}

	private void updateNiftyValue() {
		
		try(JedisCluster jedis=ConnectionProp.getRedisConnection())
		{
			if(indexRepository.existsById("NIFTY 50"))
			{
				//Index nifty=indexRepository.findById("NIFTY 50").get();
				Index nifty=preOpenUpdates.getIndexData("NIFTY 50");
				
				jedis.hset("preopenNifty", "lastPrice", String.valueOf(nifty.last));
				jedis.hset("preopenNifty", "change", String.valueOf(nifty.last - nifty.previousClose));
				jedis.hset("preopenNifty", "pChange", String.valueOf(nifty.percChange));
			}
			
			if(jedis.exists(KeyMapper.preopenStatus))
			{
				jedis.hset("preopenNifty", "status", jedis.get(KeyMapper.preopenStatus));
			}
			
		} catch (IOException e) {
			e.printStackTrace();
		}
		
	}

	private void getDataFromRDB() {
		savePreOpenData(preOpenUpdates.getPreOpenData());

	}

	private void savePreOpenData(List<PreOpenOffline> preOpenData) {

		preOpenUpdates.setPreOpenData(preOpenData);

	}
	
	public void getPreOpenData()
    {
        List<PreOpen> list = null;
        list = (List<PreOpen>)StreamSupport.stream(preOpenRepository.findAll().spliterator(), true).filter(Objects::nonNull).collect(Collectors.toList());
        preOpenUpdates.setPreOpenOnlineData(mergeOnlineOfline(list));
    }

    public List<PreOpen> mergeOnlineOfline(List<PreOpen> list)
    {
        LOGGER.info("Merging Online Ofline objects");
        for(PreOpen on : list){
        	String identifier = on.symbol + on.series + on.marketType;
            Optional<PreOpenOffline> preOpenOfflineObj = preOpenOfflineRepository.findById(identifier);
            if(preOpenOfflineObj.isPresent() && identifier.equals(((PreOpenOffline)preOpenOfflineObj.get()).identifier))
            {
                on.yearHigh = (preOpenOfflineObj.get()).yearHigh;
                on.yearLow = (preOpenOfflineObj.get()).yearLow;
                on.marketCap = (preOpenOfflineObj.get()).marketCap;
                on.finalQuantity = (preOpenOfflineObj.get()).finalQuantity;
                on.basePrice = (preOpenOfflineObj.get()).basePrice;
                on.exDate = (preOpenOfflineObj.get()).exDate;
                on.purpose = (preOpenOfflineObj.get()).purpose;
            }
        } 
        LOGGER.info("Returning from mergeOnlineOfline method");
        return list;
    }

}
