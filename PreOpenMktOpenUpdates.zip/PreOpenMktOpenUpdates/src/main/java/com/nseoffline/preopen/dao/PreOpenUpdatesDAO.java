package com.nseoffline.preopen.dao;

import java.util.List;

import com.nseindia.redis.model.Index;
import com.nseindia.redis.model.PreOpen;
import com.nseindia.redis.model.PreOpenOffline;

public interface PreOpenUpdatesDAO {
	
	List<PreOpenOffline> getPreOpenData();
	void setPreOpenData(List<PreOpenOffline> data);
	void setPreOpenOnlineData(List<PreOpen> data);
	Index getIndexData(String string);
}
