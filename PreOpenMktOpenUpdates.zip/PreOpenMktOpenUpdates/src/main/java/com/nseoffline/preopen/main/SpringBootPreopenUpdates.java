package com.nseoffline.preopen.main;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.ConfigurableApplicationContext;
import org.springframework.context.annotation.ComponentScan;

@SpringBootApplication
@ComponentScan("com.nseoffline.preopen,com.nseindia.redis")
public class SpringBootPreopenUpdates {

	public static void main(String[] args) {
		ConfigurableApplicationContext context=SpringApplication.run(SpringBootPreopenUpdates.class, args);
		context.close();
		//System.exit(0);
	}
	
}
