package com.nseoffline.preopen.model;

import com.nseindia.redis.model.Index;

public class PreOpenStatus {
	
	Index nifty;
	String timestamp;
	String marketStatus;

}
