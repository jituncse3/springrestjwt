package com.nseoffline.preopen.daoimpl;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.TimeUnit;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.nseindia.rdb.connection.JDBCConnection;
import com.nseindia.redis.model.Index;
import com.nseindia.redis.model.PreOpen;
import com.nseindia.redis.model.PreOpenOffline;
import com.nseindia.redis.repo.PreOpenOfflineRepository;
import com.nseindia.redis.repo.PreOpenRepository;
import com.nseoffline.preopen.dao.PreOpenUpdatesDAO;

@Repository
public class PreOpenUpdatesDAOImpl implements PreOpenUpdatesDAO {

	@Autowired
	PreOpenOfflineRepository offlineRepository;
	
	@Autowired
	PreOpenRepository preOpenRepository;

	private String query = "select POO_SYMBOL symbol,POO_SERIES series,POO_MARKET_TYPE marketType, POO_FINAL_QTY finalQuantity, POO_52WEEK_HIGH yearHigh, POO_52WEEK_LOW yearLow, POO_MKT_CAP mareketCap, POO_BASE_PRICE basePrice, to_char(CA_EX_DT,'dd-Mon-yyyy') exDate, CA_PURPOSE purpose from pre_open_online left join latest_eod_corp_action on  POO_SYMBOL=CA_SYMBOL and POO_SERIES=CA_SERIES where trunc(POO_TIMESTAMP)=(select max(trunc(POO_TIMESTAMP)) from pre_open_online)";

	@Override
	public List<PreOpenOffline> getPreOpenData() {

		try (Connection connection = JDBCConnection.getRDBConnection();
				Statement statement = connection.createStatement();
				ResultSet resultSet = statement.executeQuery(query)) {
			List<PreOpenOffline> list = new ArrayList<PreOpenOffline>(2000);
			PreOpenOffline offline;
			while (resultSet.next()) {
				offline = new PreOpenOffline();
				offline.identifier = resultSet.getString("symbol") + resultSet.getString("series")
						+ resultSet.getString("marketType");
				offline.yearHigh = resultSet.getDouble("yearHigh");
				offline.yearLow = resultSet.getDouble("yearLow");
				offline.marketCap = resultSet.getLong("mareketCap");
				offline.finalQuantity=resultSet.getLong("finalQuantity");
				offline.basePrice = resultSet.getDouble("basePrice");
				offline.exDate = resultSet.getString("exDate");
				offline.purpose = resultSet.getString("purpose");
				list.add(offline);
			}
			return list;
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return null;
	}

	@Override
	public void setPreOpenData(List<PreOpenOffline> data) {

		offlineRepository.deleteAll();
		ExecutorService executorService = Executors.newFixedThreadPool(5);
		data.parallelStream().forEach(x -> executorService.submit(new Runnable() {

			@Override
			public void run() {
				offlineRepository.save(x);
			}
		}));
		executorService.shutdown();
		try {
			executorService.awaitTermination(1, TimeUnit.MINUTES);
		} catch (InterruptedException e) {
			e.printStackTrace();
		}
		executorService.shutdown();

	}

	@Override
	public void setPreOpenOnlineData(List<PreOpen> data) {
		ExecutorService executorService = Executors.newFixedThreadPool(5);
		data.parallelStream().forEach(x -> executorService.submit(new Runnable() {

			@Override
			public void run() {
				preOpenRepository.save(x);
			}
		}));
		executorService.shutdown();
		try {
			executorService.awaitTermination(1, TimeUnit.MINUTES);
		} catch (InterruptedException e) {
			e.printStackTrace();
		}
		executorService.shutdown();
	}

	@Override
	public Index getIndexData(String index) {
		String queryStr = "select IPOA_INDEX_NAME indexname,IPOA_CURR_INDEX_VAL last_price,IPOA_CLOSE_INDEX_VAL previousClose,IPOA_PERC_CHG percChange from INDICES_PRE_OPEN_ALLONLINE where IPOA_INDEX_NAME = ? and IPOA_TIMESTAMP=(select max(IPOA_TIMESTAMP) from INDICES_PRE_OPEN_ALLONLINE)";
		try (Connection connection = JDBCConnection.getRDBConnection();
				PreparedStatement statement = createPreparedStatementObj(connection,queryStr,index);
				ResultSet resultSet = statement.executeQuery()) {
			Index indexObj = null;
			while (resultSet.next()) {
				indexObj = new Index();
				indexObj.last = resultSet.getDouble("last_price");
				indexObj.previousClose = resultSet.getDouble("previousClose");
				indexObj.percChange = resultSet.getDouble("percChange");
				
			}
			return indexObj;
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return null;
	}

	private PreparedStatement createPreparedStatementObj(Connection connection,String sql,String index) {
		PreparedStatement response = null;
		try {
			response =  connection.prepareStatement(sql);
			response.setString(1, index);
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return response;
	}

}
