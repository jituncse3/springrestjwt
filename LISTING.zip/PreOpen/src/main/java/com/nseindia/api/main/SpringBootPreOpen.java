package com.nseindia.api.main;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;

@SpringBootApplication
@RestController
@ComponentScan("com.nseindia.api.preopen,com.nseindia.redis")
public class SpringBootPreOpen {
	
	public static void main(String[] args) {
		
		SpringApplication.run(SpringBootPreOpen.class, args);
	}

	@GetMapping("/preopen/healthcheck")
	public String checkServiceHealth()
	{
		return " \r\n" + 
				"   ___                           \r\n" + 
				"  / _ \\_______ ___  ___  ___ ___ \r\n" + 
				" / ___/ __/ -_) _ \\/ _ \\/ -_) _ \\\r\n" + 
				"/_/  /_/  \\__/\\___/ .__/\\__/_//_/\r\n" + 
				"                 /_/             		 service is running. By ADMNSV";
	}
	
}
