package com.nseindia.api.preopen.services;

import java.io.IOException;
import java.text.DecimalFormat;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;
import java.util.stream.StreamSupport;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.nseindia.api.preopen.exception.IdentifierMissingException;
import com.nseindia.redis.connection.ConnectionProp;
import com.nseindia.redis.model.IndexOffline;
import com.nseindia.redis.model.PreOpen;
import com.nseindia.redis.repo.IndexOfflineRepository;
import com.nseindia.redis.repo.PreOpenRepository;
import com.nseindia.redis.util.KeyMapper;

import redis.clients.jedis.JedisCluster;

@Service
public class PreOpenService {

	private static final Logger LOGGER=LoggerFactory.getLogger(PreOpenService.class);
	List<String> list;
	@Autowired
	IndexOfflineRepository indexOfflineRepository;
	
	@Autowired
	PreOpenRepository preOpenRepository;
	
	public Map<String, Object> getPreOpenData(String symbol) {
		LOGGER.info(" Getting data for symbol"+symbol);
		DecimalFormat dfTwoDecimal = new DecimalFormat("#.00");
		Map<String, Object> finalData=new HashMap<>(5);
		List<PreOpen> list=null;
		IndexOffline index=null;
		switch(symbol)
		{
			case "NIFTY":
				index= indexOfflineRepository.findById("NIFTY 50").get();
				list=StreamSupport.stream(preOpenRepository.findAllById(index.constituents).spliterator(), true).filter(ob->ob.IEP>0).collect(Collectors.toList());
				break;
			case "BANKNIFTY":
				index= indexOfflineRepository.findById("NIFTY BANK").get();
				list=StreamSupport.stream(preOpenRepository.findAllById(index.constituents).spliterator(), true).filter(ob->ob.IEP>0).collect(Collectors.toList());
				break;
			case "FO":
				try(JedisCluster jedis=ConnectionProp.getRedisConnection())
				{
					Map<String, String> fosec=jedis.hgetAll(KeyMapper.foSuggest);
					list=StreamSupport.stream(preOpenRepository.findAll().spliterator(), true).filter(ob->fosec.containsKey(ob.symbol)).filter(ob->ob.IEP>0).collect(Collectors.toList());
				} catch (IOException e) {
					LOGGER.error("Unable to get Jedis connection");
				}
				break;
			case "SME":
				try(JedisCluster jedis=ConnectionProp.getRedisConnection())
				{
					String series=jedis.get(KeyMapper.smeSeries);
					list=StreamSupport.stream(preOpenRepository.findAll().spliterator(), true).filter(ob->series.contains(ob.series)).filter(ob->ob.IEP>0).collect(Collectors.toList());
				} catch (IOException e) {
					LOGGER.error("Unable to get Jedis connection");
				}
				break;
			case "OTHERS":
				try(JedisCluster jedis=ConnectionProp.getRedisConnection())
				{
					List<String> constituentList = indexOfflineRepository.findById("NIFTY 50").get().constituents;
					Map<String, String> fosec=jedis.hgetAll(KeyMapper.foSuggest);
					list=StreamSupport.stream(preOpenRepository.findAll().spliterator(), true).filter(ob->!fosec.containsKey(ob.symbol)).filter(ob->!constituentList.contains(ob.symbol)).filter(ob->ob.IEP>0).collect(Collectors.toList());
				} catch (IOException e) {
					LOGGER.error("Unable to get Jedis connection");
				}
				break;
			case "ALL":
				list=StreamSupport.stream(preOpenRepository.findAll().spliterator(), true).filter(ob->ob.IEP>0).collect(Collectors.toList());
				break;
			default:
				LOGGER.error("Invalid symbol for preopen");
				throw new IdentifierMissingException("Invalid symbol for preopen");
		}
		finalData.put("data", list);
		int advances=0,declines=0,unchanged=0;
		for (PreOpen preOpen : list) {
			double tempVal = Double.parseDouble(dfTwoDecimal.format(preOpen.pChange));
			if(tempVal > 0){
				advances++;
				LOGGER.error("#######Advances : "+preOpen.symbol+" pchange: "+tempVal);
			}	
			else if(tempVal < 0){
				declines++;
				LOGGER.error("#######Declines : "+preOpen.symbol+" pchange: "+tempVal);
			}	
			else {
				unchanged++;
				LOGGER.error("#######Unchanged : "+preOpen.symbol+" pchange: "+tempVal);
			}	
			
		}
		finalData.put("advances",advances );
		finalData.put("declines", declines);
		finalData.put("unchanged", unchanged);
		try(JedisCluster jedis=ConnectionProp.getRedisConnection())
		{
			finalData.put("timestamp", jedis.hget(KeyMapper.maxTimestamp, "preOpen"));
		} catch (IOException e) {
			LOGGER.error("Unable to get Jedis connection");
		}
		
		
		LOGGER.info("Returning data from preopen service");
		return finalData;
	}

	public PreOpen getPreOpenDataForSymbol(String symbol) {
		LOGGER.info(" Getting data for symbol"+symbol);
		PreOpen open=null;
		if(preOpenRepository.existsById(symbol))
		{
			open=preOpenRepository.findById(symbol).get();
		}
		else
		{
			LOGGER.error("Not a valid Symbol");
			throw new IdentifierMissingException("Not a valid Symbol");
		}
		
		return open;
	}

	public Map<String, String> getPreOpenStatus() {
		System.out.println("hello from preopenstatus");
		LOGGER.info(" Getting pre open status data");
		try(JedisCluster jedis=ConnectionProp.getRedisConnection())
		{
			return jedis.hgetAll("preopenNifty");
		} catch (IOException e) {
			LOGGER.error("Unable to get Jedis connection");
		}
		return null;
	}
	
	
	
}
