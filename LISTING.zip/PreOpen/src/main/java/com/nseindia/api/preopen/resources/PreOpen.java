package com.nseindia.api.preopen.resources;

import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.nseindia.api.preopen.services.PreOpenService;

@RestController
@RequestMapping("/preopen/")
public class PreOpen {
	
	private static final Logger LOGGER=LoggerFactory.getLogger(PreOpen.class);
	
	@Autowired
	PreOpenService preOpenService;
	
	@GetMapping("status")
	public Map<String, String> getPreOpenStatus()
	{
		LOGGER.info("Path /preopen/status");
		return preOpenService.getPreOpenStatus();
	}
	
	@GetMapping("{symbol}")
	public Map<String, Object> getPreOpenData(@PathVariable String symbol)
	{
		LOGGER.info("Path /preopen/{symbol} with symbol"+symbol);
		return preOpenService.getPreOpenData(symbol);
	}
	
	@GetMapping("/equities/{symbol}")
	public com.nseindia.redis.model.PreOpen getPreOpenDataForSymbol(@PathVariable String symbol)
	{
		LOGGER.info("Path /preopen/equities/{symbol} with symbol"+symbol);
		return preOpenService.getPreOpenDataForSymbol(symbol);
	}
}
