package com.nseindia.redis.model;

import org.springframework.data.redis.core.RedisHash;

@RedisHash("spread_offline")
public class SpreadOffline  extends Spread{
	
public  String tradeCount;

public void setParentData(Spread spread) {
	instrument = spread.instrument;
	symbol =spread. symbol;
	strikePrice = spread.strikePrice;
	optionType = spread.optionType;
	instrument2 = spread.instrument2;
	symbol2 = spread.symbol2;
	strikePrice2 = spread.strikePrice2;
	optionType2 = spread.optionType2;
	expiryDate = spread.expiryDate;
	buyPrice1 = spread.buyPrice1;
	buyQuantity1 =spread.buyQuantity1;
	buyPrice2 = spread.buyPrice2;
	buyQuantity2 = spread.buyQuantity2;
	buyPrice3 = spread.buyPrice3;
	buyQuantity3 = spread.buyQuantity3;
	buyPrice4 = spread.buyPrice4;
	buyQuantity4 = spread.buyQuantity4;
	buyPrice5 = spread.buyPrice5;
	buyQuantity5 = spread.buyQuantity5;
	sellPrice1 = spread.sellPrice1;
	sellQuantity1 = spread.sellQuantity1;
	sellPrice2 = spread.sellPrice2;
	sellQuantity2 = spread.sellQuantity2;
	sellPrice3 = spread.sellPrice3;
	sellQuantity3 = spread.sellQuantity3;
	sellPrice4 = spread.sellPrice4;
	sellQuantity4 = spread.sellQuantity4;
	sellPrice5 = spread.sellPrice5;
	sellQuantity5 =spread.sellQuantity5;
	openPriceDiff = spread.openPriceDiff;
	highpriceDiff = spread.highpriceDiff;
	lowPriceDiff = spread.lowPriceDiff;
	ltpDIff = spread.ltpDIff;
	totBuyVol = spread.totBuyVol;
	totSellVol = spread.totSellVol;
	totTradeVol = spread.totTradeVol;
	timeStamp = spread.timeStamp;
}

}
