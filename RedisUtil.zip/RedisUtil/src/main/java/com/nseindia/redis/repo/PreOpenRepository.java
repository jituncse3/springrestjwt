package com.nseindia.redis.repo;

import org.springframework.data.repository.CrudRepository;

import com.nseindia.redis.model.PreOpen;

public interface PreOpenRepository extends CrudRepository<PreOpen, String>{

}
