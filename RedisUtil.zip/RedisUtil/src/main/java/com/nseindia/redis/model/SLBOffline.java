package com.nseindia.redis.model;

import org.springframework.data.redis.core.RedisHash;

@RedisHash("slb_offline")
public class SLBOffline  extends SLB{
	
	public double underLyingLtp;
	public double futuresLtp;
	public double spread;
	public double spreadPer;
	public int openPositions;
	public double annulisedYieldPer;
	public double volume;
	public double turnOver;
	public double transactionValue;
	public String purpose;
	//public double tradedVolume;
	//public double tradedValue;
	public String caExpDate;
	public String caRecDate;
	public String bcStartDate;
	public String bcEndDate;
	public double securityVar;
	public double IndexVar;
	public double varMargin;
	public double extremeLossRate;
	public double adhocMargin;
	public double applicableMarginRate;
	public String isinCod;
	public void setParentData(SLB slb)
	{
		
		if(null!=slb) {
			symbol = slb.symbol;
			series = slb.series;
			marketType = slb.marketType;
			buyOrderPrice1 = slb.buyOrderPrice1;
			buyOrderQty1 = slb.buyOrderQty1;
			buyOrderPrice2 = slb.buyOrderPrice2;
			buyOrderQty2 = slb.buyOrderQty2;
			buyOrderPrice3 = slb.buyOrderPrice3;
			buyOrderQty3 = slb.buyOrderQty3;
			buyOrderPrice4 = slb.buyOrderPrice4;
			buyOrderQty4 = slb.buyOrderQty4;
			buyOrderPrice5 = slb.buyOrderPrice5;
			buyOrderQty5 = slb.buyOrderQty5;
			sellOrederPrice1 = slb.sellOrederPrice1;
			sellQty1 = slb.sellQty1;
			sellOrederPrice2 = slb.sellOrederPrice2;
			sellQty2 = slb.sellQty2;
			sellOrederPrice3 = slb.sellOrederPrice3;
			sellQty3 = slb.sellQty3;
			sellOrederPrice4 = slb.sellOrederPrice4;
			sellQty4 = slb.sellQty4;
			sellOrederPrice5 = slb.sellOrederPrice5;
			sellQty5 = slb.sellQty5;
			lastTradedPrice = slb.lastTradedPrice;
			totTradedQty = slb.totTradedQty;
			securityStatus = slb.securityStatus;
			openingPrice = slb.openingPrice;
			highPrice = slb.highPrice;
			lowPrice = slb.lowPrice;
			closePrice = slb.closePrice;
			avgTradePrice = slb.avgTradePrice;
			totBuyQty = slb.totBuyQty;
			totSellQty = slb.totSellQty;
			onlineIndex = slb.onlineIndex;
			revLegSettDt = slb.revLegSettDt;
			timeStamp = slb.timeStamp;
		}
	}
	
	
}
