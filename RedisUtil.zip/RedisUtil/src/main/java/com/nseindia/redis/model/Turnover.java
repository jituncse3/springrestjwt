package com.nseindia.redis.model;

import java.io.Serializable;
import java.time.LocalDateTime;

import org.springframework.data.annotation.Id;
import org.springframework.data.redis.core.RedisHash;

@RedisHash("marketTurnover")
public class Turnover implements Serializable{
	
	@Id
	public String product;
	public String name;
	public double turnover;
	public long tradeCount;
	public long totalTradedQauntity;
	public double premTurnover;
	public Double oivalue;
	public LocalDateTime maxDate;
	
	public Turnover() {
		
	}

	public Turnover(String product) {
		super();
		this.product = product;
	}
	 
}
