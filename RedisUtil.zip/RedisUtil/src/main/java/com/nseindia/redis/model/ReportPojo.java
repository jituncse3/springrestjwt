package com.nseindia.redis.model;

import org.springframework.data.annotation.Id;
import org.springframework.data.redis.core.RedisHash;

@RedisHash("report")
public class ReportPojo {

	@Id
	private String fileHashKey;
	private String fileKey;
	private String fileSegment;
	private String displayName;
	private String fileActlName;
	private String filePath;
	private String tradingDate;
	private Double filePosition;

	public ReportPojo() {}

	public ReportPojo(String fileHashKey, String fileKey, String fileSegment, String displayName, String fileActlName,
			String filePath, String tradingDate, Double filePosition) {
		this.fileHashKey = fileHashKey;
		this.fileKey = fileKey;
		this.fileSegment = fileSegment;
		this.displayName = displayName;
		this.fileActlName = fileActlName;
		this.filePath = filePath;
		this.tradingDate = tradingDate;
		this.filePosition = filePosition;
	}

	public String getFileHashKey() {
		return fileHashKey;
	}

	public void setFileHashKey(String fileHashKey) {
		this.fileHashKey = fileHashKey;
	}

	public String getFileSegment() {
		return fileSegment;
	}

	public void setFileSegment(String fileSegment) {
		this.fileSegment = fileSegment;
	}

	public String getFileKey() {
		return fileKey;
	}

	public void setFileKey(String fileKey) {
		this.fileKey = fileKey;
	}

	public String getDisplayName() {
		return displayName;
	}

	public void setDisplayName(String displayName) {
		this.displayName = displayName;
	}

	public String getFileActlName() {
		return fileActlName;
	}

	public void setFileActlName(String fileActlName) {
		this.fileActlName = fileActlName;
	}

	public String getFilePath() {
		return filePath;
	}

	public void setFilePath(String filePath) {
		this.filePath = filePath;
	}

	public String getTradingDate() {
		return tradingDate;
	}

	public void setTradingDate(String tradingDate) {
		this.tradingDate = tradingDate;
	}

	public Double getFilePosition() {
		return filePosition;
	}

	public void setFilePosition(Double filePosition) {
		this.filePosition = filePosition;
	}

}
