package com.nseindia.redis.model;

import java.util.List;

import org.springframework.data.redis.core.RedisHash;

@RedisHash("indexOffline")
public class IndexOffline extends Index{

	public List<String> constituents;
	public void setParentData(Index index)
	{
		if(index!=null)
		{
			 indexName=index.indexName;
			  open=index.open;
			 high=index.high;
			 low=index.low;
			 last=index.last;
			 previousClose=index.previousClose;
			 percChange=index.percChange;
			 yearHigh=index.yearHigh;
			 yearLow=index.yearLow;
			 timeVal=index.timeVal;
		}
	}
}
