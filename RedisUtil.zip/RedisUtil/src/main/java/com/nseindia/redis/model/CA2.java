package com.nseindia.redis.model;

import java.io.Serializable;

import org.springframework.data.annotation.Id;
import org.springframework.data.redis.core.RedisHash;
import org.springframework.data.redis.core.index.Indexed;

@RedisHash("ca2_online")
public class CA2 implements Serializable{
	
	@Id
	public String identifier;          
	public String timeStamp;            
	@Indexed public int sessionId;         
	public int seqNo;               
	public String symbol;             
	public String series;            
	public String marketType;          
	public double buyOrderPrice1;    
	public int buyOrderQty1;      
	public String buyFlag1;      
	public double buyOrderPrice2;    
	public int buyOrderQty2;   
	public String buyFlag2;     
	public double buyOrderPrice3; 
	public int buyOrderQty3;       
	public String buyFlag3;  
	public double buyOrderPrice4;    
	public int buyOrderQty4;      
	public String buyFlag4;       
	public double buyOrderPrice5;     
	public int buyOrderQty5;      
	public String buyFlag5;      
	public double sellOrderPrice1;   
	public int sellOrderQty1;     
	public String sellFlag1;   
	public double sellOrderPrice2;    
	public int sellOrderQty2;     
	public String sellFlag2;     
	public double sellOrderPrice3;   
	public int sellOrderQty3;     
	public String sellFlag3;     
	public double sellOrderPrice4;    
	public int sellOrderQty4;     
	public String sellFlag4;     
	public double sellOrderPrice5;    
	public int sellOrderQty5;     
	public String sellFlag5;     
	public int buyExists;      
	public int sellExists;     
	public int ieq;
	public double ltp;    
	public int ltq;      
	public int totTradedQty;       
	public String securityStatus;      
	public double openPrice;           
	public double highPrice;           
	public double lowPrice;            
	public double closePrice;	     
	public double avgTradedPrice;        
	public double iep;     
	public int totBuyQty;          
	public int totSellQty;         

	
	//Identifier is different for both online & offline as online contains session ID & offline data is same for add sessions
	public CA2Offline otherData;
	
	
	public CA2(String identifier, String timeStamp, int sessionId, int seqNo, String symbol, String series,
			String marketType, double buyOrderPrice1, int buyOrderQty1, String buyFlag1, double buyOrderPrice2,
			int buyOrderQty2, String buyFlag2, double buyOrderPrice3, int buyOrderQty3, String buyFlag3,
			double buyOrderPrice4, int buyOrderQty4, String buyFlag4, double buyOrderPrice5, int buyOrderQty5,
			String buyFlag5, double sellOrderPrice1, int sellOrderQty1, String sellFlag1, double sellOrderPrice2,
			int sellOrderQty2, String sellFlag2, double sellOrderPrice3, int sellOrderQty3, String sellFlag3,
			double sellOrderPrice4, int sellOrderQty4, String sellFlag4, double sellOrderPrice5, int sellOrderQty5,
			String sellFlag5, int buyExists, int sellExists, int ieq, double ltp, int ltq, int totTradedQty,
			String securityStatus, double openPrice, double highPrice, double lowPrice, double closePrice,
			double avgTradedPrice, double iep, int totBuyQty, int totSellQty, CA2Offline otherData) {
		super();
		this.identifier = identifier;
		this.timeStamp = timeStamp;
		this.sessionId = sessionId;
		this.seqNo = seqNo;
		this.symbol = symbol;
		this.series = series;
		this.marketType = marketType;
		this.buyOrderPrice1 = buyOrderPrice1;
		this.buyOrderQty1 = buyOrderQty1;
		this.buyFlag1 = buyFlag1;
		this.buyOrderPrice2 = buyOrderPrice2;
		this.buyOrderQty2 = buyOrderQty2;
		this.buyFlag2 = buyFlag2;
		this.buyOrderPrice3 = buyOrderPrice3;
		this.buyOrderQty3 = buyOrderQty3;
		this.buyFlag3 = buyFlag3;
		this.buyOrderPrice4 = buyOrderPrice4;
		this.buyOrderQty4 = buyOrderQty4;
		this.buyFlag4 = buyFlag4;
		this.buyOrderPrice5 = buyOrderPrice5;
		this.buyOrderQty5 = buyOrderQty5;
		this.buyFlag5 = buyFlag5;
		this.sellOrderPrice1 = sellOrderPrice1;
		this.sellOrderQty1 = sellOrderQty1;
		this.sellFlag1 = sellFlag1;
		this.sellOrderPrice2 = sellOrderPrice2;
		this.sellOrderQty2 = sellOrderQty2;
		this.sellFlag2 = sellFlag2;
		this.sellOrderPrice3 = sellOrderPrice3;
		this.sellOrderQty3 = sellOrderQty3;
		this.sellFlag3 = sellFlag3;
		this.sellOrderPrice4 = sellOrderPrice4;
		this.sellOrderQty4 = sellOrderQty4;
		this.sellFlag4 = sellFlag4;
		this.sellOrderPrice5 = sellOrderPrice5;
		this.sellOrderQty5 = sellOrderQty5;
		this.sellFlag5 = sellFlag5;
		this.buyExists = buyExists;
		this.sellExists = sellExists;
		this.ieq = ieq;
		this.ltp = ltp;
		this.ltq = ltq;
		this.totTradedQty = totTradedQty;
		this.securityStatus = securityStatus;
		this.openPrice = openPrice;
		this.highPrice = highPrice;
		this.lowPrice = lowPrice;
		this.closePrice = closePrice;
		this.avgTradedPrice = avgTradedPrice;
		this.iep = iep;
		this.totBuyQty = totBuyQty;
		this.totSellQty = totSellQty;
		if(otherData!=null)
		{
			this.otherData=otherData;
			otherData.chnge=iep-(otherData.basePrice!=0?otherData.basePrice:closePrice);
			otherData.perChnge=otherData.chnge/(otherData.basePrice!=0?otherData.basePrice:closePrice)*100;
		}
	}


	public CA2() {
		// TODO Auto-generated constructor stub
	}
	
}
