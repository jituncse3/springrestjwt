package com.nseindia.redis.model;

public class IpoActiveCategoryPojo {
	private String srNo;
	private String category;	
	private String noOfShareOffered;
	private String noOfSharesBid;
	private String noOfTotalMeant;
	/**
	 * @return the srNo
	 */
	public String getSrNo() {
		return srNo;
	}
	/**
	 * @param srNo the srNo to set
	 */
	public void setSrNo(String srNo) {
		this.srNo = srNo;
	}
	/**
	 * @return the category
	 */
	public String getCategory() {
		return category;
	}
	/**
	 * @param category the category to set
	 */
	public void setCategory(String category) {
		this.category = category;
	}
	/**
	 * @return the noOfShareOffered
	 */
	public String getNoOfShareOffered() {
		return noOfShareOffered;
	}
	/**
	 * @param noOfShareOffered the noOfShareOffered to set
	 */
	public void setNoOfShareOffered(String noOfShareOffered) {
		this.noOfShareOffered = noOfShareOffered;
	}
	/**
	 * @return the noOfSharesBid
	 */
	public String getNoOfSharesBid() {
		return noOfSharesBid;
	}
	/**
	 * @param noOfSharesBid the noOfSharesBid to set
	 */
	public void setNoOfSharesBid(String noOfSharesBid) {
		this.noOfSharesBid = noOfSharesBid;
	}
	/**
	 * @return the noOfTotalMeant
	 */
	public String getNoOfTotalMeant() {
		return noOfTotalMeant;
	}
	/**
	 * @param noOfTotalMeant the noOfTotalMeant to set
	 */
	public void setNoOfTotalMeant(String noOfTotalMeant) {
		this.noOfTotalMeant = noOfTotalMeant;
	}
	
}
