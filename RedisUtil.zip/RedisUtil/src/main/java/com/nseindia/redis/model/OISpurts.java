package com.nseindia.redis.model;

import java.io.Serializable;
import java.util.List;

import org.springframework.data.annotation.Id;
import org.springframework.data.redis.core.RedisHash;

@RedisHash("oispurts")
public class OISpurts implements Serializable {
	
	@Id
	public String indetifier;
	public String currTradingDate;
	public String prevTradingDate;
	public String timestamp;
	public List<OISpurtsPojo> underlyingDataList;
	public List<OISpurtsContractPojo> riseInOiRise;
	public List<OISpurtsContractPojo> riseInOiSlide;
	public List<OISpurtsContractPojo> slideInOiRise;
	public List<OISpurtsContractPojo> slideInOiSlide;
}
