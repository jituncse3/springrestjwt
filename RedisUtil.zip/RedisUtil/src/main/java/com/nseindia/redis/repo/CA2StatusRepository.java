package com.nseindia.redis.repo;

import java.util.List;

import org.springframework.data.repository.CrudRepository;

import com.nseindia.redis.model.CA2Status;

public interface CA2StatusRepository extends CrudRepository<CA2Status, String> {

	List<CA2Status> findAllBysessionId(int sessionId);
}
