package com.nseindia.redis.model;

import java.io.Serializable;

import org.springframework.data.annotation.Id;
import org.springframework.data.redis.core.RedisHash;

@RedisHash("debt_offline")
public class DebtOffline implements Serializable{

	@Id
	public String identifier;
	public String symbol;
	public String series;
	public String couponRate;
	public String isinCode;
	public String issueDesc;
	public String issueDate;
	public String maturityDate;
	public double faceValue;
	public String bondType;
	public String nxtIpDate;
	public String creditRating; 
	public double ytm; //added by mustak
}
