package com.nseindia.redis.repo;

import org.springframework.data.repository.CrudRepository;

import com.nseindia.redis.model.OISpurts;

public interface OISpurtsRepository extends CrudRepository<OISpurts, String>{

}
