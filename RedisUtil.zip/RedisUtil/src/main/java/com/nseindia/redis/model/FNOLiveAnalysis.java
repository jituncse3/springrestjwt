package com.nseindia.redis.model;

import java.io.Serializable;

import org.springframework.data.annotation.Id;
import org.springframework.data.redis.core.RedisHash;

@RedisHash("fno_liveanalysis")
public class FNOLiveAnalysis implements Serializable{
	
	@Id
	private String identifier;
	private long openInterest;
	private double underlyingValue;
	
	public String getIdentifier() {
		return identifier;
	}
	public void setIdentifier(String identifier) {
		this.identifier = identifier;
	}
	public long getOpenInterest() {
		return openInterest;
	}
	public void setOpenInterest(long openInterest) {
		this.openInterest = openInterest;
	}
	public double getUnderlyingValue() {
		return underlyingValue;
	}
	public void setUnderlyingValue(double underlyingValue) {
		this.underlyingValue = underlyingValue;
	}

}
