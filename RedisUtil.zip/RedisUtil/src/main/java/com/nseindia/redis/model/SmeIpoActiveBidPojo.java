package com.nseindia.redis.model;

public class SmeIpoActiveBidPojo {
private String srNo;
private String category;
private String noOfshareBid;
/**
 * @return the srNo
 */
public String getSrNo() {
	return srNo;
}
/**
 * @param srNo the srNo to set
 */
public void setSrNo(String srNo) {
	this.srNo = srNo;
}
/**
 * @return the category
 */
public String getCategory() {
	return category;
}
/**
 * @param category the category to set
 */
public void setCategory(String category) {
	this.category = category;
}
/**
 * @return the noOfshareBid
 */
public String getNoOfshareBid() {
	return noOfshareBid;
}
/**
 * @param noOfshareBid the noOfshareBid to set
 */
public void setNoOfshareBid(String noOfshareBid) {
	this.noOfshareBid = noOfshareBid;
}

}
