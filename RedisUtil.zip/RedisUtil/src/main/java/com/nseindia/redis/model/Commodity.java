package com.nseindia.redis.model;

import java.io.Serializable;

import org.springframework.data.annotation.Id;
import org.springframework.data.redis.core.RedisHash;

@RedisHash("commodity_online")
public class Commodity implements Serializable{
	
	@Id
	public String identifier;
	public String instrumentType;
	public String underlying;
	public String expiryDate;
	public double strikePrice;
	public String optionType;
	public String marketType;
	public double buyPrice1;
	public long buyQuantity1;
	public double buyPrice2;
	public long buyQuantity2;
	public double buyPrice3;
	public long buyQuantity3;
	public double buyPrice4;
	public long buyQuantity4;
	public double buyPrice5;
	public long buyQuantity5;
	public double sellPrice1;
	public long sellQuantity1;
	public double sellPrice2;
	public long sellQuantity2;
	public double sellPrice3;
	public long sellQuantity3;
	public double sellPrice4;
	public long sellQuantity4;
	public double sellPrice5;
	public long sellQuantity5;
	public double lastPrice;
	public long totalTradedVolume;
	public String secStatus;
	public double openPrice;
	public double highPrice;
	public double lowPrice;
	public double prevClose;
	public double avgtradePrice;
	public long totalBuyQuantity;
	public long totalSellQuantity;
	public String last_updatedTime;
	
	
	//calculated
	public double change;
	public double pChange;
	public double totalTurnover;
	public double premiumTurnover;
	
	public Commodity() {
	}

	public Commodity(String identifier, String instrumentType, String underlying, String expiryDate, double strikePrice,
			String optionType, String marketType, double buyPrice1, long buyQuantity1, double buyPrice2,
			long buyQuantity2, double buyPrice3, long buyQuantity3, double buyPrice4, long buyQuantity4,
			double buyPrice5, long buyQuantity5, double sellPrice1, long sellQuantity1, double sellPrice2,
			long sellQuantity2, double sellPrice3, long sellQuantity3, double sellPrice4, long sellQuantity4,
			double sellPrice5, long sellQuantity5, double lastPrice, long totalTradedVolume, String secStatus,
			double openPrice, double highPrice, double lowPrice, double prevClose, double avgtradePrice,
			long totalBuyQuantity, long totalSellQuantity, String last_updatedTime) {
		super();
		this.identifier = identifier;
		this.instrumentType = instrumentType;
		this.underlying = underlying;
		this.expiryDate = expiryDate;
		this.strikePrice = strikePrice;
		this.optionType = optionType;
		this.marketType = marketType;
		this.buyPrice1 = buyPrice1;
		this.buyQuantity1 = buyQuantity1;
		this.buyPrice2 = buyPrice2;
		this.buyQuantity2 = buyQuantity2;
		this.buyPrice3 = buyPrice3;
		this.buyQuantity3 = buyQuantity3;
		this.buyPrice4 = buyPrice4;
		this.buyQuantity4 = buyQuantity4;
		this.buyPrice5 = buyPrice5;
		this.buyQuantity5 = buyQuantity5;
		this.sellPrice1 = sellPrice1;
		this.sellQuantity1 = sellQuantity1;
		this.sellPrice2 = sellPrice2;
		this.sellQuantity2 = sellQuantity2;
		this.sellPrice3 = sellPrice3;
		this.sellQuantity3 = sellQuantity3;
		this.sellPrice4 = sellPrice4;
		this.sellQuantity4 = sellQuantity4;
		this.sellPrice5 = sellPrice5;
		this.sellQuantity5 = sellQuantity5;
		this.lastPrice = lastPrice;
		this.totalTradedVolume = totalTradedVolume;
		this.secStatus = secStatus;
		this.openPrice = openPrice;
		this.highPrice = highPrice;
		this.lowPrice = lowPrice;
		this.prevClose = prevClose;
		this.avgtradePrice = avgtradePrice;
		this.totalBuyQuantity = totalBuyQuantity;
		this.totalSellQuantity = totalSellQuantity;
		this.last_updatedTime = last_updatedTime;
		
		change=lastPrice-prevClose;
		pChange=(change/prevClose)*100;
		/*
		 * As per business requirement from 18-Apr-2019 onwards, Total turnover key will be Premium turnover value and Premium turnover key will have Notional turnover value. Premium turnover no more exists.   
		 */
		totalTurnover=totalTradedVolume*(avgtradePrice);
		premiumTurnover=totalTradedVolume*(avgtradePrice+strikePrice);
	}

}
