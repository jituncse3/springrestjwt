package com.nseindia.redis.model;

import java.io.Serializable;

import org.springframework.data.annotation.Id;
import org.springframework.data.redis.core.RedisHash;
@RedisHash("sprecial_preopen")
public class SpecialPreopen implements Serializable {
	@Id
	public String identifier;          
	public String timeStamp;   
	public String symbol;
	public String series;
	public String marketType;
	public SpecialPreopen(String identifier, String timeStamp, String symbol, String series, String marketType) {
		super();
		this.identifier = identifier;
		this.timeStamp = timeStamp;
		this.symbol = symbol;
		this.series = series;
		this.marketType = marketType;
	}
	
}
