package com.nseindia.redis.util;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.TimeZone;

public class Formulas {
	
	/*private static LocalDate now = LocalDate.now();
	private static DateTimeFormatter formatter = new DateTimeFormatterBuilder().parseCaseInsensitive().appendPattern("dd-MM-yyyy").toFormatter();
	
	public static double getCostOfCarry(double param1, double underlyingValue, String expiryDate)
	{
		if(param1!=0)
		{
			LocalDate expiry= LocalDate.parse(expiryDate,formatter);
			long diff=ChronoUnit.DAYS.between(now,expiry);
			if(diff!=0)
				return (Math.log(param1/underlyingValue)/diff)*36500;
			else
				return 0;
		}
		return 0;	
	}*/
	
	private static SimpleDateFormat dateFormat = new SimpleDateFormat("dd-MM-yyyy");
	private static SimpleDateFormat localZoneFormat = new SimpleDateFormat("dd-MM-yyyy HH:mm:ss z");
	
	public static double getCostOfCarry(double param1, double underlyingValue, String expiryDate) 
	{
		dateFormat.setTimeZone(TimeZone.getTimeZone("IST"));
		
		if(param1!=0)
		{
			try {
				Date expDate = dateFormat.parse(expiryDate);
				Date curDate = dateFormat.parse(localZoneFormat.format(new Date()));
				long diff= (int) ((expDate.getTime() - curDate.getTime()) / (1000 * 60 * 60 * 24));
				if(diff!=0)
					return (Math.log(param1/underlyingValue)/diff)*36500;
				else
					return 0;
			} catch (ParseException e) {
				e.printStackTrace();
			}
			
		}
		return 0;	
	}
	

}
