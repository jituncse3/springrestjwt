package com.nseindia.redis.repo;

import org.springframework.data.repository.CrudRepository;

import com.nseindia.redis.model.OfsIssueInfo;

public interface OfsIssueInfoRepository extends CrudRepository<OfsIssueInfo, String>{

}
