package com.nseindia.redis.repo;

import java.util.List;
import org.springframework.data.repository.CrudRepository;
import com.nseindia.redis.model.CDOffline;

public interface CDOfflineRepository extends CrudRepository<CDOffline, String>{
	List<CDOffline> findAllByInstrumentType(String instrumentType); //added By Mustak
}
