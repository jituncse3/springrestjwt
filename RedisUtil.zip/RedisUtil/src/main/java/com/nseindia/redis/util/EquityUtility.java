package com.nseindia.redis.util;

import java.util.Arrays;
import java.util.List;

public class EquityUtility {
	
	static final String allSeries[]=new String[]{"EQ","BE","BL","BT","D1","D2","D3","DE","DR","DT","DL","E1","E2","GC","IL","K1","N1","N2","N3","N4","N5","N6","N7","N8","N9","NA","NB","NC","ND","NE","NF","NG","NH","NI","NJ","NK","NL","NM","NN","NO","NP","NQ","NR","NS","NT","NU","NV","NW","NX","O1","P1","P2","P3","P4","Q1","Q2","U2","W1","W2","IQ","H1","H2","H3","H4","NY","NZ","Y1","Y2","Y3","Y4","Y5","Y6","Y7","Y8","Y9","YA","YB","YC","YD","YG","BZ","GB","IV","ID","YH","YI","YJ","YK","YL","YM","YN","YO"};
	//static final String debtSeries[]=new String[]{"N1","N2","N3","N4","N5","N6","N7","N8","N9","NA","NB","NC","ND","NE","NF","NG","NH","NI","NJ","NK","NL","NM","NN","NO","NP","NQ","NR","NS","NT","NU","NV","NW","NX","NY","NZ","Y1","Y2","Y3","Y4","Y5","Y6","H1","H2","H3","H4","H5","H6","H7","H8","H9","HA","HB","HC","HD"};
	static final String debtSeries[]=new String[]{"N1","N2","N3","N4","N5","N6","N7","N8","N9","NA","NB","NC","ND","NE","NF","NG","NH","NI","NJ","NK","NL","NM","NN","NO","NP","NQ","NR","NS","NT","NU","NV","NW","NX","NY","NZ","Y1","Y2","Y3","Y4","Y5","Y6","H1","H2","H3","H4","H5","H6","H7","H8","H9","HA","HB","HC","HD","YP","YQ","YR","YS","YT","YU","YV","YW","YX","YY","YZ","Z1","Z2"};
	public static List<String> debtSeriesList;
	static
	{
		debtSeriesList=Arrays.asList(debtSeries);
	}
	
}
