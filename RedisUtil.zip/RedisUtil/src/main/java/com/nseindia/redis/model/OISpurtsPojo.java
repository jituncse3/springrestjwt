package com.nseindia.redis.model;

public class OISpurtsPojo{
	
	private String symbol;
	private String foSymbol;
	private long latestOI;
	private long prevOI;
	private int change;
	private double pChange;
	private long volume;
	private long value;
	private long underlyingValue;
	private int isFo;
	private long premValue;
	private long futValue;
	private long optValue;
	private long total;
	private long turnover;
	
	public String getSymbol() {
		return symbol;
	}
	public void setSymbol(String symbol) {
		this.symbol = symbol;
	}
	public String getFoSymbol() {
		return foSymbol;
	}
	public void setFoSymbol(String foSymbol) {
		this.foSymbol = foSymbol;
	}
	public long getLatestOI() {
		return latestOI;
	}
	public void setLatestOI(long latestOI) {
		this.latestOI = latestOI;
	}
	public long getPrevOI() {
		return prevOI;
	}
	public void setPrevOI(long prevOI) {
		this.prevOI = prevOI;
	}
	public int getChange() {
		return change;
	}
	public void setChange(int change) {
		this.change = change;
	}
	public double getpChange() {
		return pChange;
	}
	public void setpChange(double pChange) {
		this.pChange = pChange;
	}
	public long getVolume() {
		return volume;
	}
	public void setVolume(long volume) {
		this.volume = volume;
	}
	public long getValue() {
		return value;
	}
	public void setValue(long value) {
		this.value = value;
	}
	public long getUnderlyingValue() {
		return underlyingValue;
	}
	public void setUnderlyingValue(long underlyingValue) {
		this.underlyingValue = underlyingValue;
	}
	public int getIsFo() {
		return isFo;
	}
	public void setIsFo(int isFo) {
		this.isFo = isFo;
	}
	public long getPremValue() {
		return premValue;
	}
	public void setPremValue(long premValue) {
		this.premValue = premValue;
	}
	public long getFutValue() {
		return futValue;
	}
	public void setFutValue(long futValue) {
		this.futValue = futValue;
	}
	public long getOptValue() {
		return optValue;
	}
	public void setOptValue(long optValue) {
		this.optValue = optValue;
	}
	public long getTotal() {
		return total;
	}
	public void setTotal(long total) {
		this.total = total;
	}
	public long getTurnover() {
		return turnover;
	}
	public void setTurnover(long turnover) {
		this.turnover = turnover;
	}
	
	
}
