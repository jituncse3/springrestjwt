package com.nseindia.redis.model;

public class PriceBandHittersPojo {

	private String symbol;
	private String series;
	private String ltp;
	private String change;
	private String pChange;
	private String priceBand;
	private double highPrice;
	private double lowPrice;
	private double yearHigh;
	private double yearLow;
	private long totalTradedVol;
	private double turnover;
	
	public String getSymbol() {
		return symbol;
	}
	public void setSymbol(String symbol) {
		this.symbol = symbol;
	}
	public String getSeries() {
		return series;
	}
	public void setSeries(String series) {
		this.series = series;
	}
	public String getLtp() {
		return ltp;
	}
	public void setLtp(String ltp) {
		this.ltp = ltp;
	}
	public String getChange() {
		return change;
	}
	public void setChange(String change) {
		this.change = change;
	}
	public String getpChange() {
		return pChange;
	}
	public void setpChange(String pChange) {
		this.pChange = pChange;
	}
	public String getPriceBand() {
		return priceBand;
	}
	public void setPriceBand(String priceBand) {
		this.priceBand = priceBand;
	}
	public double getHighPrice() {
		return highPrice;
	}
	public void setHighPrice(double highPrice) {
		this.highPrice = highPrice;
	}
	public double getLowPrice() {
		return lowPrice;
	}
	public void setLowPrice(double lowPrice) {
		this.lowPrice = lowPrice;
	}
	public double getYearHigh() {
		return yearHigh;
	}
	public void setYearHigh(double yearHigh) {
		this.yearHigh = yearHigh;
	}
	public double getYearLow() {
		return yearLow;
	}
	public void setYearLow(double yearLow) {
		this.yearLow = yearLow;
	}
	public long getTotalTradedVol() {
		return totalTradedVol;
	}
	public void setTotalTradedVol(long totalTradedVol) {
		this.totalTradedVol = totalTradedVol;
	}
	public double getTurnover() {
		return turnover;
	}
	public void setTurnover(double turnover) {
		this.turnover = turnover;
	}
	
	
	
	
}
