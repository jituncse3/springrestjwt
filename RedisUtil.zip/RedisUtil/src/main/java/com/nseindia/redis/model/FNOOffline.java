package com.nseindia.redis.model;

import org.springframework.data.redis.core.RedisHash;

import com.nseindia.redis.util.Formulas;

@RedisHash("fno_offline")
public class FNOOffline extends FNO{
	
	public String companyName;
	public Double closePrice;
	public double annualisedVolatility;
	public long clientWisePositionLimits;
	public long marketWidePositionLimits;
	public long marketLot;
	public double openInterest;
	public double dailyvolatility;
	public double prevOI;
	public double impliedVolatility;
	public double settlementPrice;
	public double underlyingValue;
	public int noOfContractsTraded;

	//calculated
	public double changeinOpenInterest;
	public double pchangeinOpenInterest;
	public double ccBestBuy;
	public double ccBestSell;
	public double ccLTP;
	
	//volume freeze quantity
	public long volumeFreezeQuantity;
	
	public FNOOffline() {
		super();
		// TODO Auto-generated constructor stub
	}
	
	public void setParentData(FNO fno)
	{
		if(fno!=null)
		{
			identifier = fno.identifier;
			instrumentType = fno.instrumentType;
			underlying = fno.underlying;
			expiryDate = fno.expiryDate;
			strikePrice = fno.strikePrice;
			optionType = fno.optionType;
			maturityDt 	= fno.maturityDt ;
			marketType 	= fno.marketType ;
			buyPrice1 	= fno.buyPrice1 ;
			buyQuantity1 	= fno.buyQuantity1 ;
			buyPrice2 	= fno.buyPrice2 ;
			buyQuantity2 	= fno.buyQuantity2 ;
			buyPrice3 	= fno.buyPrice3 ;
			buyQuantity3 	= fno.buyQuantity3 ;
			buyPrice4 	= fno.buyPrice4 ;
			buyQuantity4 	= fno.buyQuantity4 ;
			buyPrice5 	= fno.buyPrice5 ;
			buyQuantity5 	= fno.buyQuantity5 ;
			sellPrice1 	= fno.sellPrice1 ;
			sellQuantity1 	= fno.sellQuantity1 ;
			sellPrice2 	= fno.sellPrice2 ;
			sellQuantity2 	= fno.sellQuantity2 ;
			sellPrice3 	= fno.sellPrice3 ;
			sellQuantity3 	= fno.sellQuantity3 ;
			sellPrice4 	= fno.sellPrice4 ;
			sellQuantity4 	= fno.sellQuantity4 ;
			sellPrice5 	= fno.sellPrice5 ;
			sellQuantity5 	= fno.sellQuantity5 ;
			lastPrice 	= fno.lastPrice ;
			totalTradedVolume 	= fno.totalTradedVolume ;
			securityStatus 	= fno.securityStatus ;
			openPrice 	= fno.openPrice ;
			highPrice 	= fno.highPrice ;
			lowPrice 	= fno.lowPrice ;
			prevClose 	= fno.prevClose ;
			avgtradePrice 	= fno.avgtradePrice ;
			totalBuyQuantity 	= fno.totalBuyQuantity ;
			totalSellQuantity 	= fno.totalSellQuantity ;
			lastUpdateTime 	= fno.lastUpdateTime ;
			change=fno.change;
			pChange=fno.pChange;
			premiumTurnover=fno.premiumTurnover;
			totalTurnover=fno.totalTurnover;
			
			if(instrumentType.contains("FUT") || underlyingValue!=0)
			{
				ccBestBuy=Formulas.getCostOfCarry(buyPrice1, underlyingValue, expiryDate);
				ccBestSell=Formulas.getCostOfCarry(sellPrice1, underlyingValue, expiryDate);
				ccLTP=Formulas.getCostOfCarry(lastPrice, underlyingValue, expiryDate);
			}
		}
	}
	
	
}
