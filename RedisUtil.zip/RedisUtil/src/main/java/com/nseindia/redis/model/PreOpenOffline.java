package com.nseindia.redis.model;

import java.io.Serializable;

import org.springframework.data.annotation.Id;
import org.springframework.data.redis.core.RedisHash;

@RedisHash("preOpenOffline")
public class PreOpenOffline implements Serializable{
	
	@Id
	public String identifier;
	public double yearHigh;
	public double yearLow;
	public long marketCap;
	public long finalQuantity;
	public double basePrice;
	public String exDate;
	public String purpose;
}
