package com.nseindia.redis.repo;

import java.util.List;

import org.springframework.data.repository.CrudRepository;

import com.nseindia.redis.model.FNOOffline;

public interface FNOOfflineRepository extends CrudRepository<FNOOffline, String>{
	
	List<FNOOffline> findAllByInstrumentType(String instrumentType);

}
