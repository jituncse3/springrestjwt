package com.nseindia.redis.repo;

import org.springframework.data.repository.CrudRepository;

import com.nseindia.redis.model.IndexOffline;

public interface IndexOfflineRepository extends CrudRepository<IndexOffline, String>{

}
