package com.nseindia.redis.model;

import java.util.List;

import org.springframework.data.annotation.Id;
import org.springframework.data.redis.core.RedisHash;
@RedisHash("sme_ipo_issues_info")
public class SmeIpoIssuesInfo {
	@Id
	private String symbol;
	private String heading;
	private List<IpoActiveMidPojo> dataList;
	/**
	 * @return the symbol
	 */
	public String getSymbol() {
		return symbol;
	}
	/**
	 * @param symbol the symbol to set
	 */
	public void setSymbol(String symbol) {
		this.symbol = symbol;
	}
	/**
	 * @return the heading
	 */
	public String getHeading() {
		return heading;
	}
	/**
	 * @param heading the heading to set
	 */
	public void setHeading(String heading) {
		this.heading = heading;
	}
	/**
	 * @return the dataList
	 */
	public List<IpoActiveMidPojo> getDataList() {
		return dataList;
	}
	/**
	 * @param dataList the dataList to set
	 */
	public void setDataList(List<IpoActiveMidPojo> dataList) {
		this.dataList = dataList;
	}
	
}
