package com.nseindia.redis.model;

import java.io.Serializable;

import org.springframework.data.annotation.Id;
import org.springframework.data.redis.core.RedisHash;

@RedisHash("ca2Offline")
public class CA2Offline implements Serializable{

	@Id
	public String symbol;
	public String series;
	public String companyName;
	public String isin;
	public int faceValue;
	public double yearHigh;
	public double yearLow;
	public String yearHighDt;
	public String yearLowDt;
	public long tradedQty;
	public long deliverableQty;
	public double pdeliverableQty;
	public double secVar;
	public double indexVar;
	public double varMargin;
	public double extremeLossRate;
	public double adhocMargin;
	public double applicableMarginRt;
	public String priceBand;
	
	public double basePrice;
	//calulated

	public double chnge;
	public double perChnge;
	
}
