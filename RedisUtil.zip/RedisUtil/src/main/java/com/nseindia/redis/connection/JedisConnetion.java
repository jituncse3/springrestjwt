package com.nseindia.redis.connection;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.data.redis.connection.RedisClusterConfiguration;
import org.springframework.data.redis.connection.RedisStandaloneConfiguration;
import org.springframework.data.redis.connection.jedis.JedisConnectionFactory;
import org.springframework.data.redis.core.RedisTemplate;
import org.springframework.data.redis.repository.configuration.EnableRedisRepositories;

@Configuration
@EnableRedisRepositories(basePackages="com.nseindia.redis.repo")
public class JedisConnetion {
	
	@Bean
	JedisConnectionFactory connectionFactory()
	{
		RedisStandaloneConfiguration configuration=new RedisStandaloneConfiguration(ConnectionProp.hostname);
		//RedisClusterConfiguration clusterConfiguration=new RedisClusterConfiguration().clusterNode(ConnectionProp.node1,ConnectionProp.port1).clusterNode(ConnectionProp.node2,ConnectionProp.port2);
		return new JedisConnectionFactory(configuration);
	}
	
	@Bean	
	RedisTemplate<String, Object> redisTemplate()
	{
		RedisTemplate<String, Object> redisTemplate =new RedisTemplate<String, Object>();
		redisTemplate.setConnectionFactory(connectionFactory());
		return redisTemplate;
	}

}
