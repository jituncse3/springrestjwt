package com.nseindia.rdb.connection;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

public class JDBCConnection {
	
	public static Connection getRDBConnection()
	{
		try {
			return DriverManager.getConnection(DBProperty.url, DBProperty.username, DBProperty.pa$$word);
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return null;
	}
}
