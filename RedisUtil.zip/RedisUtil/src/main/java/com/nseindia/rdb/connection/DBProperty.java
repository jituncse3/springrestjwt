package com.nseindia.rdb.connection;

public class DBProperty {
		

	
	public static String url;
	public static String username;
	public static String pa$$word;
	
	
	static
	{
		url="jdbc:oracle:thin:@//172.17.106.48:1541/neapsora";
		username="neapsdba";
		pa$$word="abcd1234";
	}
	/*static 
	{
		if(System.getenv("DB_URL")!=null)
		{
			url=System.getenv("DB_URL");
			username=System.getenv("DB_USER");
			pa$$word=System.getenv("DB_PASSWORD");
		}
		else
		{
			url="jdbc:oracle:thin:@(description=(address=(host=host_ip)(protocol=tcp)(port=port))(connect_data=(sid=nseweb12) (SERVER=DEDICATED)))";
			username="user";
			pa$$word="pass";
		}
	}*/
}
